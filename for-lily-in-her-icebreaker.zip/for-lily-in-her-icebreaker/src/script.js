<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Family Feud - Survey Says!</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Anton:wght@400&family=Roboto:wght@400;700;900&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(45deg, #1a237e, #3949ab, #5c6bc0);
            font-family: 'Roboto', sans-serif;
            min-height: 100vh;
            color: white;
            overflow-x: hidden;
        }
        
        .game-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            position: relative;
        }
        
        .title {
            font-family: 'Anton', sans-serif;
            font-size: 4rem;
            color: #FFD700;
            text-shadow: 3px 3px 0 #FF6B35, 6px 6px 10px rgba(0,0,0,0.5);
            margin-bottom: 10px;
            animation: glow 2s ease-in-out infinite alternate;
        }
        
        @keyframes glow {
            from { text-shadow: 3px 3px 0 #FF6B35, 6px 6px 10px rgba(0,0,0,0.5), 0 0 20px #FFD700; }
            to { text-shadow: 3px 3px 0 #FF6B35, 6px 6px 10px rgba(0,0,0,0.5), 0 0 30px #FFD700, 0 0 40px #FFD700; }
        }
        
        .subtitle {
            font-size: 1.5rem;
            color: #FFD700;
            font-weight: bold;
            margin-bottom: 20px;
        }
        
        .game-board {
            background: linear-gradient(135deg, #1565c0, #0d47a1);
            border: 8px solid #FFD700;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.4);
            margin-bottom: 30px;
            position: relative;
        }
        
        .game-board::before {
            content: '';
            position: absolute;
            top: -4px;
            left: -4px;
            right: -4px;
            bottom: -4px;
            background: linear-gradient(45deg, #FF6B35, #FFD700, #FF6B35);
            border-radius: 24px;
            z-index: -1;
            animation: borderGlow 3s linear infinite;
        }
        
        @keyframes borderGlow {
            0%, 100% { opacity: 0.8; }
            50% { opacity: 1; }
        }
        
        .question-display {
            text-align: center;
            margin-bottom: 40px;
            background: rgba(0,0,0,0.3);
            padding: 20px;
            border-radius: 15px;
            border: 3px solid #FFD700;
        }
        
        .question-text {
            font-size: 2rem;
            font-weight: bold;
            color: #FFD700;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            margin-bottom: 10px;
        }
        
        .answers-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 8px;
            margin-bottom: 30px;
        }
        
        .answer-row {
            background: linear-gradient(135deg, #0d47a1, #1565c0);
            border: 4px solid #FFD700;
            border-radius: 12px;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .answer-row:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(255,215,0,0.3);
            background: linear-gradient(135deg, #1565c0, #1976d2);
        }
        
        .answer-row.revealed {
            background: linear-gradient(135deg, #2e7d32, #43a047);
            animation: reveal 0.8s ease-out;
        }
        
        @keyframes reveal {
            0% {
                transform: rotateY(90deg);
                background: linear-gradient(135deg, #0d47a1, #1565c0);
            }
            50% {
                transform: rotateY(45deg);
            }
            100% {
                transform: rotateY(0deg);
                background: linear-gradient(135deg, #2e7d32, #43a047);
            }
        }
        
        .answer-number {
            background: #FFD700;
            color: #000;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        .answer-text {
            flex: 1;
            margin: 0 20px;
            font-size: 1.4rem;
            font-weight: bold;
            text-align: center;
            text-transform: uppercase;
        }
        
        .answer-points {
            background: #FF6B35;
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .hidden {
            opacity: 0.3;
        }
        
        .hidden .answer-text {
            color: transparent;
            text-shadow: none;
        }
        
        .hidden .answer-points {
            color: transparent;
        }
        
        .game-controls {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            justify-content: center;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .control-group {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(0,0,0,0.3);
            padding: 15px 20px;
            border-radius: 15px;
            border: 2px solid #FFD700;
        }
        
        .btn {
            background: linear-gradient(135deg, #FF6B35, #ff8a65);
            border: none;
            color: white;
            padding: 12px 25px;
            font-size: 1.1rem;
            font-weight: bold;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255,107,53,0.4);
            background: linear-gradient(135deg, #ff8a65, #FF6B35);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-buzzer {
            background: linear-gradient(135deg, #d32f2f, #f44336);
            font-size: 1.3rem;
            padding: 15px 30px;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 4px 15px rgba(0,0,0,0.3); }
            50% { box-shadow: 0 4px 15px rgba(244,67,54,0.6), 0 0 25px rgba(244,67,54,0.3); }
            100% { box-shadow: 0 4px 15px rgba(0,0,0,0.3); }
        }
        
        .btn-buzzer:hover {
            background: linear-gradient(135deg, #f44336, #d32f2f);
            box-shadow: 0 6px 25px rgba(244,67,54,0.6);
        }
        
        .score-display {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }
        
        .score-item {
            background: linear-gradient(135deg, #1a237e, #283593);
            border: 4px solid #FFD700;
            border-radius: 15px;
            padding: 20px 30px;
            text-align: center;
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }
        
        .score-label {
            font-size: 1.1rem;
            color: #FFD700;
            margin-bottom: 8px;
            text-transform: uppercase;
            font-weight: bold;
        }
        
        .score-value {
            font-size: 2.5rem;
            font-weight: 900;
            color: white;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }
        
        .strikes {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin: 20px 0;
        }
        
        .strike {
            width: 40px;
            height: 40px;
            border: 3px solid #FFD700;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .strike.active {
            background: #f44336;
            color: white;
            animation: strikeFlash 0.5s ease-out;
        }
        
        @keyframes strikeFlash {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.2); background: #ff1744; }
        }
        
        .input-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        input[type="text"] {
            padding: 12px 15px;
            border: 2px solid #FFD700;
            border-radius: 10px;
            background: rgba(255,255,255,0.9);
            color: #000;
            font-size: 1rem;
            font-weight: bold;
        }
        
        input[type="text"]:focus {
            outline: none;
            box-shadow: 0 0 10px rgba(255,215,0,0.5);
        }
        
        .feedback {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #2e7d32, #43a047);
            color: white;
            padding: 30px 50px;
            border-radius: 20px;
            font-size: 2rem;
            font-weight: bold;
            text-align: center;
            box-shadow: 0 15px 50px rgba(0,0,0,0.5);
            border: 4px solid #FFD700;
            z-index: 1000;
            animation: feedbackShow 2s ease-out forwards;
        }
        
        .feedback.wrong {
            background: linear-gradient(135deg, #d32f2f, #f44336);
        }
        
        @keyframes feedbackShow {
            0% {
                transform: translate(-50%, -50%) scale(0);
                opacity: 0;
            }
            20% {
                transform: translate(-50%, -50%) scale(1.1);
                opacity: 1;
            }
            80% {
                transform: translate(-50%, -50%) scale(1);
                opacity: 1;
            }
            100% {
                transform: translate(-50%, -50%) scale(0);
                opacity: 0;
            }
        }
        
        @media (max-width: 768px) {
            .title {
                font-size: 2.5rem;
            }
            
            .question-text {
                font-size: 1.5rem;
            }
            
            .answer-text {
                font-size: 1.2rem;
            }
            
            .game-controls {
                flex-direction: column;
            }
            
            .control-group {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="game-container">
        <div class="header">
            <h1 class="title">FAMILY FEUD</h1>
            <p class="subtitle">Survey Says...</p>
        </div>
        
        <div class="game-board">
            <div class="question-display">
                <div class="question-text" id="question">Name something you might find in a kitchen</div>
            </div>
            
            <div class="answers-grid" id="answersGrid">
                <!-- Answers will be dynamically generated -->
            </div>
            
            <div class="strikes">
                <div class="strike" id="strike1">X</div>
                <div class="strike" id="strike2">X</div>
                <div class="strike" id="strike3">X</div>
            </div>
        </div>
        
        <div class="game-controls">
            <div class="control-group">
                <div class="input-group">
                    <input type="text" id="guessInput" placeholder="Enter your answer...">
                    <button class="btn" onclick="submitGuess()">Submit</button>
                </div>
            </div>
            
            <div class="control-group">
                <button class="btn btn-buzzer" onclick="playBuzzer()">BUZZER!</button>
                <button class="btn" onclick="newGame()">New Game</button>
                <button class="btn" onclick="revealAll()">Reveal All</button>
            </div>
        </div>
        
        <div class="score-display">
            <div class="score-item">
                <div class="score-label">Current Score</div>
                <div class="score-value" id="currentScore">0</div>
            </div>
            <div class="score-item">
                <div class="score-label">Revealed</div>
                <div class="score-value" id="revealedCount">0/8</div>
            </div>
            <div class="score-item">
                <div class="score-label">Strikes</div>
                <div class="score-value" id="strikeCount">0/3</div>
            </div>
        </div>
    </div>

    <script>
        // Game data
        const gameQuestions = [
            {
                question: "Name something you might find in a kitchen",
                answers: [
                    { text: "REFRIGERATOR", points: 32 },
                    { text: "STOVE", points: 28 },
                    { text: "SINK", points: 24 },
                    { text: "DISHES", points: 18 },
                    { text: "MICROWAVE", points: 16 },
                    { text: "UTENSILS", points: 12 },
                    { text: "FOOD", points: 8 },
                    { text: "CABINETS", points: 6 }
                ]
            },
            {
                question: "Name something people do at the beach",
                answers: [
                    { text: "SWIMMING", points: 38 },
                    { text: "SUNBATHING", points: 26 },
                    { text: "BUILDING SANDCASTLES", points: 18 },
                    { text: "SURFING", points: 15 },
                    { text: "VOLLEYBALL", points: 12 },
                    { text: "READING", points: 8 },
                    { text: "FISHING", points: 6 },
                    { text: "WALKING", points: 4 }
                ]
            },
            {
                question: "Name something you might pack for a vacation",
                answers: [
                    { text: "CLOTHES", points: 42 },
                    { text: "TOOTHBRUSH", points: 28 },
                    { text: "CAMERA", points: 22 },
                    { text: "SUNSCREEN", points: 16 },
                    { text: "SHOES", points: 12 },
                    { text: "PASSPORT", points: 10 },
                    { text: "PHONE CHARGER", points: 8 },
                    { text: "MEDICATION", points: 5 }
                ]
            },
            {
                question: "Name something associated with winter",
                answers: [
                    { text: "SNOW", points: 45 },
                    { text: "COLD WEATHER", points: 32 },
                    { text: "CHRISTMAS", points: 24 },
                    { text: "ICE", points: 18 },
                    { text: "SKIING", points: 14 },
                    { text: "HOT CHOCOLATE", points: 10 },
                    { text: "FIREPLACE", points: 8 },
                    { text: "SWEATERS", points: 6 }
                ]
            }
        ];
        
        // Game state
        let currentQuestion = 0;
        let currentScore = 0;
        let strikes = 0;
        let revealedAnswers = 0;
        let gameData = {};
        
        // Audio context for sound effects
        let audioContext;
        
        function initAudio() {
            try {
                audioContext = new (window.AudioContext || window.webkitAudioContext)();
            } catch (e) {
                console.log("Audio not supported");
            }
        }
        
        function playSound(frequency, duration, type = 'sine') {
            if (!audioContext) return;
            
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = frequency;
            oscillator.type = type;
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + duration);
        }
        
        function playBuzzer() {
            initAudio();
            // Classic game show buzzer sound
            playSound(200, 0.5, 'square');
            setTimeout(() => playSound(150, 0.3, 'square'), 100);
        }
        
        function playCorrectSound() {
            initAudio();
            // Success chime
            playSound(523, 0.2); // C
            setTimeout(() => playSound(659, 0.2), 100); // E
            setTimeout(() => playSound(784, 0.3), 200); // G
        }
        
        function playWrongSound() {
            initAudio();
            // Wrong answer sound
            playSound(220, 0.8, 'sawtooth');
        }
        
        function initGame() {
            gameData = gameQuestions[currentQuestion];
            renderGame();
            updateScore();
        }
        
        function renderGame() {
            document.getElementById('question').textContent = gameData.question;
            
            const answersGrid = document.getElementById('answersGrid');
            answersGrid.innerHTML = '';
            
            gameData.answers.forEach((answer, index) => {
                const answerRow = document.createElement('div');
                answerRow.className = 'answer-row hidden';
                answerRow.setAttribute('data-index', index);
                
                answerRow.innerHTML = `
                    <div class="answer-number">${index + 1}</div>
                    <div class="answer-text">${answer.text}</div>
                    <div class="answer-points">${answer.points}</div>
                `;
                
                answersGrid.appendChild(answerRow);
            });
        }
        
        function submitGuess() {
            const input = document.getElementById('guessInput');
            const guess = input.value.trim().toUpperCase();
            
            if (!guess) return;
            
            const matchedAnswer = gameData.answers.find(answer => 
                answer.text.includes(guess) || 
                guess.includes(answer.text.split(' ')[0]) ||
                levenshteinDistance(guess, answer.text) <= 2
            );
            
            if (matchedAnswer) {
                revealAnswer(matchedAnswer);
                showFeedback("GOOD ANSWER!", false);
                playCorrectSound();
            } else {
                addStrike();
                showFeedback("STRIKE!", true);
                playWrongSound();
            }
            
            input.value = '';
            updateScore();
        }
        
        function revealAnswer(answer) {
            const index = gameData.answers.indexOf(answer);
            const answerRow = document.querySelector(`[data-index="${index}"]`);
            
            if (answerRow && answerRow.classList.contains('hidden')) {
                answerRow.classList.remove('hidden');
                answerRow.classList.add('revealed');
                currentScore += answer.points;
                revealedAnswers++;
                
                if (revealedAnswers === gameData.answers.length) {
                    setTimeout(() => {
                        showFeedback("SURVEY SAYS... YOU WIN!", false);
                        playCorrectSound();
                    }, 1000);
                }
            }
        }
        
        function addStrike() {
            if (strikes < 3) {
                strikes++;
                document.getElementById(`strike${strikes}`).classList.add('active');
                
                if (strikes >= 3) {
                    setTimeout(() => {
                        showFeedback("THREE STRIKES... GAME OVER!", true);
                        playWrongSound();
                    }, 500);
                }
            }
        }
        
        function showFeedback(message, isWrong) {
            const feedback = document.createElement('div');
            feedback.className = `feedback ${isWrong ? 'wrong' : ''}`;
            feedback.textContent = message;
            
            document.body.appendChild(feedback);
            
            setTimeout(() => {
                document.body.removeChild(feedback);
            }, 2000);
        }
        
        function updateScore() {
            document.getElementById('currentScore').textContent = currentScore;
            document.getElementById('revealedCount').textContent = `${revealedAnswers}/${gameData.answers.length}`;
            document.getElementById('strikeCount').textContent = `${strikes}/3`;
        }
        
        function newGame() {
            currentQuestion = (currentQuestion + 1) % gameQuestions.length;
            currentScore = 0;
            strikes = 0;
            revealedAnswers = 0;
            
            // Reset strikes display
            for (let i = 1; i <= 3; i++) {
                document.getElementById(`strike${i}`).classList.remove('active');
            }
            
            initGame();
        }
        
        function revealAll() {
            gameData.answers.forEach(answer => {
                revealAnswer(answer);
            });
            updateScore();
        }
        
        // Utility function for fuzzy string matching
        function levenshteinDistance(str1, str2) {
            const matrix = [];
            
            for (let i = 0; i <= str2.length; i++) {
                matrix[i] = [i];
            }
            
            for (let j = 0; j <= str1.length; j++) {
                matrix[0][j] = j;
            }
            
            for (let i = 1; i <= str2.length; i++) {
                for (let j = 1; j <= str1.length; j++) {
                    if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
                        matrix[i][j] = matrix[i - 1][j - 1];
                    } else {
                        matrix[i][j] = Math.min(
                            matrix[i - 1][j - 1] + 1,
                            matrix[i][j - 1] + 1,
                            matrix[i - 1][j] + 1
                        );
                    }
                }
            }
            
            return matrix[str2.length][str1.length];
        }
        
        // Event listeners
        document.getElementById('guessInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                submitGuess();
            }
        });
        
        // Initialize the game
        initGame();
        
        // Initialize audio on first user interaction
        document.addEventListener('click', initAudio, { once: true });
    </script>
</body>
</html>