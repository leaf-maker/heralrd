# for lily in her icebreaker

A Pen created on CodePen.

Original URL: [https://codepen.io/Fritz-Eguia/pen/XJmXVMd](https://codepen.io/Fritz-Eguia/pen/XJmXVMd).

this is for my girlfriend and tbhis is her icebreaker for her report 